#ifndef _SEEK_H
#define _SEEK_H
#include <stdio.h>
#include <stdlib.h>

#define MIN_CMD_LINE_ARGS 2
#define ARG_OF_N 1

#ifndef __SEEK_ERRORS__
#define __SEEK_ERRORS__
enum Errors {MISSING_ARGS, INVALID_N_NOT_INT, INVALID_N_NEGATIVE, INVALID_FILE, LACK_OF_FILE_CHARS};
#define REACHED_ERROR(ERROR) {\
    switch(ERROR) {\
    case MISSING_ARGS:\
        fprintf(stderr, "Not enough arguments. Please use the format: ./seek [Nth-char-to-view] <file-names>...\n\n");\
        exit(EXIT_FAILURE);\
        \
    case INVALID_N_NOT_INT:\
        fprintf(stderr, "Error: %s is not a valid number. Halting Program.\n\n", argv[arg]);\
        exit(EXIT_FAILURE);\
        \
    case INVALID_N_NEGATIVE:\
        fprintf(stderr, "Error: Argument#1 (%d) is not a positive integer. Halting Program.\n\n", n);\
        exit(EXIT_FAILURE);\
        \
    case INVALID_FILE:\
        fprintf(stderr, "Error: No such file as %s\n", argv[arg]);\
        break;\
        \
    case LACK_OF_FILE_CHARS:\
        fprintf(stderr, "Error in file <%s>:\n"\
        "Unable to reach character at position [%d] since this file only has [%d] characters.\n", argv[arg], n, fSize);\
        break;\
    }\
}
#endif
#endif
