#include <seek.h>

int main(int argc, char **argv)
{
    int scanRes, fSize, n, arg=1;
    FILE *fp=NULL;
    char temp;

    if (argc<=MIN_CMD_LINE_ARGS)
        REACHED_ERROR(MISSING_ARGS);
    if ((scanRes=sscanf(argv[arg], " %d %c", &n, &temp))!=1)
        REACHED_ERROR(INVALID_N_NOT_INT);
    if (n<=0)
        REACHED_ERROR(INVALID_N_NEGATIVE);

    while (++arg<argc) {
        putchar('\n');
        if (!(fp=fopen(argv[arg], "r"))) {
            REACHED_ERROR(INVALID_FILE);
            continue;
        }
        if (fseek(fp, 0L, SEEK_END) || n>(fSize=ftell(fp)-1)) {
            REACHED_ERROR(LACK_OF_FILE_CHARS);
            fclose(fp);
            continue;
        }
        fseek(fp, n-1, SEEK_SET);
        printf("ASCII code of the %dth character in %s: %d\n", n, argv[arg], fgetc(fp));
        fclose(fp);
    }
    putchar('\n');

    return 0;
}
