#!/bin/bash

echo "

    Making sure all files are up to date...
------------------------------------------------
"
echo make clean: & make clean
echo
echo make: & make
echo "
----------------------done----------------------


                Starting tests...
------------------------------------------------"
if [ $# -eq 1 ]
then
    ./seek "$1" tests/*
    echo "----------------------done----------------------
    "
else
    echo "
Error! Invalid flags.
Use as follows: ./run_tests.sh <some_number>

---------------------failed---------------------
"
fi
